 const bankMenu = [
   {
     name: "Dashboard",
     path: "/bloodbank/dashboard",
     icon: "fa-solid fa-user",
   },

   {
     name: "Requests",
     path: "/bloodbank/blood_requests",
     icon: "fa-solid fa-user-doctor",
   },
   {
     name: "Update Data",
     path: "/bloodbank/update_data",
     icon: "fa-solid fa-user",
   },
   {
     name: "Home",
     path: "/",
     icon: "fa-solid fa-home",
   },
 ];
  
  export default bankMenu;