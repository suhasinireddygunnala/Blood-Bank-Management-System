import React from 'react'
import Layout from '../Layout/Layout'

const Gallery = () => {
  return (
    <Layout>
      <h1>Gallery page </h1>
    </Layout>
  );
}

export default Gallery