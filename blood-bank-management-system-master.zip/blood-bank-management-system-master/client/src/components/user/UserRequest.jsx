import React, { useRef, useState } from 'react';
import { Form, Input, message ,Select} from "antd";
import {useNavigate } from "react-router-dom";
import axios from "axios";
import Layout from '../Layout/Layout';

const UserRequest = () => {
const [setDate] = useState('');
const dateInputRef = useRef(null);

const handleChange = (e) => {
setDate(e.target.value);
};

const navigate=useNavigate()

const onfinishHandler=async (values)=>{
  try {
    const res = await axios.post("/api/v1/user/blood-request", values);
    
    if(res.data.success)
    {
      message.success('submitted successfully')
      navigate("/dashboard/user");
    }else{
      message.error("hello"+res.data)
    }
  } catch (error) {
    console.log(error)
    message.error('something went wrong')
  }
}
  const options=[
   { value:'A+',label:'A+'},
   { value:'A-',label:'A-'},
   { value:'B+',label:'B+'},
   { value:'B-',label:'B-'},
   { value:'AB+',label:'AB+'},
   { value:'AB-',label:'AB-'},
   { value:'O+',label:'O+'},
   { value:'O-',label:'O-'},
   { value:'A2-',label:'A2-'},
   { value:'A2+',label:'A2+'},
   { value:'A1B-',label:'A1B-'},
   { value:'A1B+',label:'A1B+'},
   { value:'A2B+',label:'A2B+'},
   { value:'A2B-',label:'A2B-'},
   { value:'Bombay Blood group',label:'Bombay Blood group'},
   { value:'INRA',label:'INRA'},
  { value:"Don't know",label:"Don't know"},
   ]
  return (
    <Layout>
      <div className="form-container ">
        <Form
          layout="vertical"
          onFinish={onfinishHandler}
          className="register-form"
        >
          <h3 className="text-center">Request Form</h3>
          <Form.Item label="Name" name="name">
            <Input type="text"  />
          </Form.Item>
          <Form.Item label="Email" name="email">
            <Input type="email"  />
          </Form.Item>
          <Form.Item label="Contact Number" name="phone">
            <Input type="number"  />
          </Form.Item>
          <Form.Item label="Units required" name="units">
            <Input type="number"  />
          </Form.Item>
          <Form.Item label="Select Blood Group"name='bloodgroup'>
            <Select  >
            {
              options.map((item,id)=>(
                <Select.Option key={id} value={item.value}>{item.label}</Select.Option>
              )
              )
            }
           </Select>
          </Form.Item>
          
          <Form.Item name='DOB'>
             <Input type="date"
             onChange={handleChange}
             ref={dateInputRef} 
             />

          </Form.Item>
          <Form.Item label="Location" name="address">
            <Input type="string" />
          </Form.Item>
          <Form.Item label="Doctor Approval" name="doctorapproval" >
            <Input type="file"id="file-input" name="ImageStyle"  />
          </Form.Item>

          
          <button className="btn btn-primary" type="submit">
            Submit
          </button>
        </Form>
      </div>
    </Layout>
  );
};

export default UserRequest;
