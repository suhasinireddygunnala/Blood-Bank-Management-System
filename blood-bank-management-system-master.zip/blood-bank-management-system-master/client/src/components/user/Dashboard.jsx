import React from 'react'
import DashboardLayout from '../Layout/DashboardLayout'
const Dashboard = () => {
  return (
    <DashboardLayout title={"Dashboard-BloodBank app"}>
      <h2> user Dashboard</h2>
    </DashboardLayout>
  );
}

export default Dashboard                