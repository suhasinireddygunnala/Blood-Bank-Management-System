import React from "react";
import BankDashboardLayout from "../Layout/BankDashboardLayout";
const RequestsToBank = () => {
  return (
    <BankDashboardLayout>
      <div></div>
    </BankDashboardLayout>
  );
};

export default RequestsToBank;