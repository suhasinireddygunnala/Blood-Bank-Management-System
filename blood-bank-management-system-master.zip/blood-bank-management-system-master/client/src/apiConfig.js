const ApiBaseUrl = "http://localhost:8000/api/v1/user"
export {ApiBaseUrl}